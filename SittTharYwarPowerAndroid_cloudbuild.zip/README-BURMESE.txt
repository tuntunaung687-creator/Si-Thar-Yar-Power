စည်သာယာ မီးအချိန် Android project

အတည်ပြုထားသော စည်းမျဉ်း:
- ဇယားမှာ A ဖြစ်နေသော ၄ နာရီအပိုင်းတွင် အုပ်စု A မီးလာ၊ အုပ်စု B မီးပျက်။
- ဇယားမှာ B ဖြစ်နေသော ၄ နာရီအပိုင်းတွင် အုပ်စု B မီးလာ၊ အုပ်စု A မီးပျက်။
- ရက်စွဲအလိုက် A/B စတင်ပုံသည် ပုံထဲက 2026-10-03 = A, 2026-10-04 = B အတိုင်း အလှည့်ကျ။

APK build:
1. PC ပေါ် Android Studio ကို install လုပ်ပါ။
2. ဒီ project folder ကို Android Studio မှ Open လုပ်ပါ။
3. Gradle sync ပြီး Build > Build APK(s) ကိုနှိပ်ပါ။
4. APK ကို app/build/outputs/apk/debug/app-debug.apk မှာရပါမယ်။

မှတ်ချက်: ဒီ ZIP သည် Android Studio source project ဖြစ်ပြီး APK ဖိုင်ကိုယ်တိုင် မဟုတ်ပါ။ Android SDK ပါသော PC ပေါ်တွင် build လုပ်ရပါမည်။

အလွယ်ဆုံး Cloud Build နည်း:
1) ဒီ ZIP ကို GitHub repository အသစ်တစ်ခုထဲ upload လုပ်ပါ။
2) Actions tab > Build Android APK > Run workflow ကိုနှိပ်ပါ။
3) အောင်မြင်သွားလျှင် workflow run ထဲက Artifacts အောက်မှ sitt-thar-ywar-debug-apk ကို download လုပ်ပါ။
ဤလုပ်ငန်းစဉ်အတွက် GitHub account နှင့် upload/run လုပ်ရန် သင်ကိုယ်တိုင် ခွင့်ပြုချက်ပေးရန်လိုသည်။
